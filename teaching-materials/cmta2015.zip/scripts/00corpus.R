##############################################################
### Подготовка среды: установка и загрузка необходимых пакетов
##############################################################

install.packages("tm")
install.packages("SnowballC")
library(tm)
library(SnowballC)

#######################################################
### Чтение данных: загрузка текстов в R-объект (Corpus)
#######################################################

# Вариант 1: тексты в .csv-файле
collection<-read.table("school.csv",sep="\t", header=T, stringsAsFactors=F, encoding="UTF-8") # загружаем файл в data.frame
corp<-Corpus(VectorSource(collection$text), readerControl=list(language="ru", encoding="UTF-8")) # берем тексты из колонки "text"

# Вариант 2: тексты в каталоге
corp<-Corpus(DirSource("txt", encoding="UTF-8"), readerControl=list(language="ru")) # загружаем тексты из каталога txt

## Проверка: смотрим первый текст в корпусе, он должен быть читабелен
inspect(corp[1]) # метаданные документа
as.character(corp[[1]]) # текст документа


##########################################################################
### Препроцессинг: нормализация текстов, подготовка к расчету частотностей
##########################################################################

## Графическая нормализация: регистр, пунктуация, числа
corp<-tm_map(corp, content_transformer(tolower)) # приведение к нижнему регистру
corp<-tm_map(corp, removePunctuation) # удаляем пунктуацию
corp<-tm_map(corp, removeNumbers) # удаляем числа

## Лексическая нормализация: стоп-слова и стемминг
corp<-tm_map(corp, removeWords, stopwords("ru")) # удаление стоп-слов из "стандартного" списка
stopwords("ru") # просмотреть, что мы удалили
##stoplist<-scan("stopwords.txt", what="", sep="\n") # удаляем стоп-слова из нашего собственного списка
corp<-tm_map(corp, stripWhitespace) # удаляем лишние пробелы (образовавшиеся после предыдущих удалений)
stemmed<-tm_map(corp, stemDocument) # стемминг — урезание слов до основы
content(stemmed[[1]]) # смотрим результат стемминга
### Дополнение основ
completed <- tm_map(corp, content_transformer(function(x, corp)
  paste(stemCompletion(strsplit(stemDocument(x), ' ')[[1]], corp), collapse = ' ')), corp)
##completed<-tm_map(stemmed, content_transformer(stemCompletion), dictionary=corp, type="prevalent") # дополняем основы до полных слов
corp<-stemmed

content(corp[[1]]) # смотрим результат препроцессинга


########################################################
### Killer feature: построение матрицы термов-документов
########################################################

dtm.control <- list(weighting=weightTf, stemming=FALSE, bounds=list(global=c(10,1000))) # выставляем настройки препроцессинга
dtm<-DocumentTermMatrix(stemmed, control=dtm.control) # строим матрицу
colnames(dtm)<-stemCompletion(Terms(dtm), corp, type="prevalent") # дополняем основы до полных слов

################################
### Простая частотная статистика
################################

findFreqTerms(dtm, 100) # вывести список слов, которые встречаются в корпусе чаще 100 раз
findFreqTerms(dtm, 1) # вывести список hapax legomena
Zipf_plot(dtm) # построить график распределения частот (закон Ципфа)

### Построение частотного списка
###~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
## 1. Преобразовать матрицу термов-документов в R-объект типа "матрица"
## 2. Вычислить суммы колонок матрицы (общие частотности слов)
## 3. Отсортировать по убыванию
## 4. Преобразовать в R-объект типа "data.frame"
freqlist<-sort(slam::col_sums(dtm), decreasing=TRUE) # построить частотный список
freqlist.df <- data.frame(word=names(freqlist), freq=freqlist)

### Запись частотного списка в файл
###~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
write.table(freqlist.df, file = "freqlist.csv", sep = ";", col.names = TRUE) # создаем в рабочей папке базу, которую можно посмотреть

### Визуализация частотного списка: Wordcloud
###~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#install.packages("wordcloud")
library(wordcloud)
wordcloud(freqlist.df$word, freqlist.df$freq, max.words=100)


### N-grams — частотность н-грамм
###~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
install.packages("tau")
library(tau)
tokenize_ngrams <- function(x, n=3) return(rownames(as.data.frame(unclass(textcnt(x,method="string",n=n)))))
ngram.control <- list(weighting=weightTf, stemming=FALSE, bounds=list(global=c(10,1000), tokenize=tokenize_ngrams)) # выставляем настройки препроцессинга
dtm3<-DocumentTermMatrix(corp, control=ngram.control) # строим матрицу

