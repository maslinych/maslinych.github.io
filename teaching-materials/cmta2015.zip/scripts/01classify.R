install.packages("caret")
library(caret)

########################
### Необходимые данные
########################

## corp — Corpus()
## dtm — DocumentTermMatrix()
## labels — метки классов

###########################################
### Подготовка обучающей и тестовой выборки
###########################################

## зафиксируем случайные числа
#set.seed(191)

## Случайная выборка
index <- 1:nrow(dtm) # номера документов от 1 до N
trainindex <- sample(index, trunc(length(index)*0.8)) # 80% случайных номеров (обучающая выборка)

## Стратифицированная выборка, сохраняющая частотность классов
dp <- createDataPartition(labels, times=1, p=0.8)
trainindex <- dp$Resample1

training<-as.matrix(dtm[trainindex,]) # матрица обучающей выборки
testing<-as.matrix(dtm[-trainindex,]) # матрица тестовой выборки
trainlabels<-labels[trainindex]
testlabels<-labels[-trainindex]

###############################
## Обучение модели
###############################

## Настройка параметров обучения
cvCtrl <- trainControl(method = "cv") #  10-fold cross-validation

## Список доступных методов
names(getModelInfo())
## См. также http://topepo.github.io/caret/bytag.html

## Запуск процедуры обучения
rpartFit <- train(training, trainlabels, method="rpart", trControl=cvCtrl)
rfFit <- train(training, trainlabels, method="rf", trControl=cvCtrl)

###############################
## Оценка качества
###############################

## Предсказание классов на тестовой выборке с помощью обученной модели
rpartClasses<-predict(rpartFit, newdata = testing)
rfClasses<-predict(rfFit, newdata = testing)

## Confusion Matrix
rpartCM <- confusionMatrix(data = rpartClasses, reference=testlabels, positive="TRUE")
rpartCM # просмотрим результаты теста

rfCM <- confusionMatrix(data = rfClasses, reference=testlabels, positive="TRUE")


###############################
## Анализ переменных
###############################

varImp(rpartFit) # двадцать самых важных переменных
varImp(rfFit) # двадцать самых важных переменных
