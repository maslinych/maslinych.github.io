install.packages("mallet")
library(mallet)

##############################################
### LDA: загрузка данных и настройка модели
##############################################

# загружаем текстовые файлы из указанного каталога
documents <- mallet.read.dir("lsplit")
# токенизация текстов
mallet.instances <- mallet.import(documents$id, documents$text, "stopwords.txt", token.regexp = "[\\p{L}\\p{N}-]*\\p{L}+")

## настраиваем параметры модели и загружаем данные
topic.model <- MalletLDA(num.topics=100) # количество тем
topic.model$loadDocuments(mallet.instances) 
topic.model$setAlphaOptimization(20, 50) # оптимизация гиперпараметров

## собираем статистику: словарь и частотность
vocabulary <- topic.model$getVocabulary() # словарь корпуса
word.freqs <- mallet.word.freqs(topic.model) # таблица частотности слов
## вершина частотного списка (по документной частоте)
head(word.freqs[order(word.freqs$doc.freq, decreasing=TRUE),],30)

# write top-100 most frequent words to file "stopwords.txt"
write.table(head(word.freqs[order(word.freqs$term.freq, decreasing=T),],100)$words, "stopwords.txt", row.names=FALSE, quote=FALSE)


#################################################
### LDA: обучение модели
#################################################

## параметр — количество итераций
topic.model$train(1000)

## выбор наилучшей темы для каждого токена
topic.model$maximize(10)


###############################
### LDA: выгрузка результатов
###############################

## таблица распределения тем по документам
doc.topics <- mallet.doc.topics(topic.model, smoothed=TRUE, normalized=TRUE)
## таблица распределения слов по темам
topic.words <- mallet.topic.words(topic.model, smoothed=TRUE, normalized=TRUE)
## метки для тем (по трем главным словам)
topic.labels <- mallet.topic.labels(topic.model, topic.words, 3)

######################################
### АНАЛИЗ РЕЗУЛЬТАТОВ: стандартные
######################################

## просмотр топ-10 слов для всех тем
for (k in 1:nrow(topic.words)) {
    top <- paste(mallet.top.words(topic.model, topic.words[k,], 10)$words,collapse=" ")
    cat(paste(k, top, "\n"))
}

## первые несколько документов, в которых вес темы не менее 5%
head(documents[ doc.topics[7,] > 0.05 & doc.topics[10,] > 0.05, ])

## Визуализация сходства тем (иерархическая кластеризация)
## сходство по совместной встречаемости в документах
plot(mallet.topic.hclust(doc.topics, topic.words, 0), labels=topic.labels) 
# сходство по набору слов в теме
plot(mallet.topic.hclust(doc.topics, topic.words, 1), labels=topic.labels)
# сбалансированное сходство по словам и документам
plot(mallet.topic.hclust(doc.topics, topic.words, 0.5), labels=topic.labels)


#######################################
### АНАЛИЗ РЕЗУЛЬТАТОВ: сравнение групп
#######################################

## загружаем метаданные (мужские и женские тексты)
metadata<-read.table("school-metadata.csv", sep="\t", header=TRUE)

## предпочтения лексики внутри тем (по группам)
male.topic.words <- mallet.subset.topic.words(topic.model, metadata$sex=="m", smoothed=TRUE, normalized=TRUE) # топ-слова в мужских текстах
female.topic.words <- mallet.subset.topic.words(topic.model, metadata$sex=="f", smoothed=TRUE, normalized=TRUE) # топ-слова в женских темах

## сравнение топ-слов в женских и мужских текстах
for (k in 1:nrow(topic.words)) {
    maletop <- paste(mallet.top.words(topic.model, male.topic.words[k,], 10)$words, collapse=" ")
    femaletop <- paste(mallet.top.words(topic.model, female.topic.words[k,], 10)$words, collapse=" ")
    cat(paste(k, "муж:", maletop, "\n"))
    cat(paste(k, "жен:", femaletop, "\n"))
}

#############################
## ИНТЕРАКТИВНАЯ ВИЗУАЛИЗАЦИЯ
#############################
install.packages("LDAvis")
install.packages("servr")
library(LDAvis)
library(servr)

## подготовка данных
## для визуализации потребуется рассчитать длину документов в словах
library(tm)
corp <- Corpus(DirSource("lsplit/")) # загружаем корпус
dtm <- DocumentTermMatrix(corp) # строим матрицу термов-документов
doc.length <- slam::row_sums(dtm) # считаем количество слов (токенов)

## настройка визуализации
json <- createJSON(phi = topic.words, theta=doc.topics, doc.length=doc.length, vocab=vocabulary, term.frequency=word.freqs$term.freq)

## запуск интерактивного интерфейса
serVis(json, out.dir="lda100", open.browser=TRUE)


###################################
### Анализ связи пола автора и темы
###################################

install.packages("ggplot2")
library(ggplot2)

## Анализ по методу (Jockers, Mimno 2013)
## выделяем в метаданных названия произведений
novels <- sub(".*/([^/]*)\\.[0-9]+\\.txt", "\\1", documents$id)
## строим таблицу соответствий произведений полу автора
gender <- aggregate(metadata$sex, list(novel=novels), function(x){x[1]})
## строим таблицу пропорций тем в каждом произведении
novel.topics <- aggregate(doc.topics, list(novel=novels),sum)
## нормализуем (приводим сумму тем к 1)
topic.props <- novel.topics[,2:ncol(novel.topics)]
topic.props <- topic.props/rowSums(topic.props)
## вычисляем среднюю долю тем для авторов мужчин и женщин
topic.gender <- aggregate(topic.props, list(gender=gender$x), mean)

## готовим таблицу среднего веса тем при случайной перестановке пола авторов
gender.permuted <- list(f=list(),m=list())
for (i in 1:100) {
    perm <- sample(gender$x)
    nagg <- aggregate(topic.props, list(gender=perm), mean)
             gender.permuted$f[[i]] <- nagg[nagg$gender=="f",]
             gender.permuted$m[[i]] <- nagg[nagg$gender=="m",]
 }
permuted.f <- do.call(rbind, gender.permuted$f)
permuted.m <- do.call(rbind, gender.permuted$m)
gender.permuted <- rbind(permuted.f, permuted.m)

## для каждой темы строим график, отражающий реальные средние и разброс средних при случайных перестановках пола
for (k in seq(1,ncol(topic.props))) {
    topic.name <- paste("V", k, sep="")
    p <- ggplot(data=topic.gender, aes(x=factor(gender))) + aes_string(y=topic.name) + geom_point(size=4) 
    p <- p + geom_point(data=gender.permuted, position="jitter", colour="blue")
    p <- p + ggtitle(paste("Topic", k,  topic.labels[k]))
    ggsave(p, filename=paste(ncol(topic.props), "topic", k, ".png", sep=""))
     }
