#install.packages("magrittr")
library(tm)
library(stringr)
library(magrittr)


####################
### Загрузка данных
####################
## словарь оценочной лексики
sentdict <- read.table("sentdict.txt", header=FALSE, stringsAsFactors=FALSE)
sentdict <- sentdict[order(sentdict$V1),] ## сортируем словарь в алфавитном порядке

## корпус отзывов
src <- read.csv("review.csv", sep=";", stringsAsFactors=FALSE) ## исходные тексты
src$Sex %<>% str_trim # убираем пробелы в колонке пола автора
corp <- Corpus(VectorSource(src$Review)) ## корпус с исходными текстами
lem <- read.csv("review-lem.csv", sep=";", stringsAsFactors=FALSE) ## лемматизированные тексты
lem$Sex %<>% str_trim # убираем пробелы в колонке пола автора
lemmata <- Corpus(VectorSource(lem$Review)) ## корпус с лемматизированными текстами
pos <- read.csv("review-pos.csv", sep=";", stringsAsFactors=FALSE, quote="", header=FALSE)
gram <- Corpus(VectorSource(pos$V1))

#################################
### Подготовка данных для расчета
#################################
## совмещаем построение матрицы термов-документов с чисткой корпуса
dtm <- DocumentTermMatrix(lemmata, control=list(removePunctuation=TRUE, removeNumbers=TRUE, wordLengths=c(0,Inf), stemming=FALSE, stopwords=FALSE)) ## все слова, включая короткие
grammar <- DocumentTermMatrix(gram, control=list(removePunctuation=TRUE, removeNumbers=TRUE, wordLengths=c(0,Inf), tokenize=Regexp_Tokenizer("[^.,-={}\"|()]+"), stemming=FALSE, stopwords=FALSE)) ## матрица грамматических показателей
## матрица для расчета степени оценочности
score <- DocumentTermMatrix(lemmata, control=list(removePunctuation=TRUE, removeNumbers=TRUE, wordLengths=c(0,Inf), stemming=FALSE, stopwords=FALSE, dictionary=sentdict$V1))
## вычисляем суммарный вес оценочных слов в каждом отзыве
sentweights <- apply(as.matrix(score), 1, function (x,y) {sum(x*sentdict$V2)})
## вычисляем длину текстов
charlength <- sapply(src$Review, nchar)

## Смотрим распределение веса оценочных слов в зависимости от длины текста
plot(log(charlength), log(sentweights)) ## график логарифмический
## строим регрессию длины текста в зависимости от веса оценочных слов
vfit.sentbylength <- lm(log(charlength) ~ log(sentweights + 1))
sentresiduals <- fit.sentbylength$residuals ## извлекаем остатки

############################
### Визуализация
###########################
library(ggplot2)
## распределение оценочности отзывов
plot(density(sentresiduals)) ## с поправкой на длину отзыва

## рисуем распределение степени оценочности отзывов по полу
ggplot(src, aes(x=as.factor(Sex), y=sentresiduals, group=as.factor(Sex))) + geom_boxplot(aes(fill=as.factor(Sex)))

## есть ли разница в оценочности между М и Ж?
malesent <- sentresiduals[src$Sex=="М"]
femalesent <- sentresiduals[src$Sex=="Ж"]
t.test(malesent, femalesent)

## среднее значение оценочности отзыва по автору
byauthor <- aggregate(sentweights, list(author=src$Author), mean)
head(byauthor[order(-byauthor$x),]) ## самые оценочные отзывы
head(byauthor[order(byauthor$x),]) ## самые нейтральные отзывы

## гипотеза: проверить длину отзыва
lengthbyauthor <- aggregate(charlength, list(author=src$Author), mean)
head(lengthbyauthor[order(-lengthbyauthor$x),]) ## самые длинные отзывы
head(lengthbyauthor[order(lengthbyauthor$x),]) ## самые короткие отзывы

## с поправкой на длину отзыва: 
sentbyauthor <- aggregate(sentresiduals, list(author=src$Author), mean)
head(lengthbyauthor[order(-lengthbyauthor$x),]) ## самые оценочные с поправкой на длину
head(sentbyauthor[order(sentbyauthor$x),]) ## самые нейтральные с поправкой на длину

##########################
### Проверка гипотез
##########################
## разбиваем отзывы на классы: выраженно оценочные, выраженно
## нейтральные, средние
sentclass <- rep.int(0, length(sentresiduals)) ## пустой вектор для классов
sentclass[sentresiduals<fivenum(sentresiduals)[2]] <- -1 ## 1 квартиль — нейтральные
sentclass[sentresiduals>fivenum(sentresiduals)[4]] <- 1 ## 4 квартиль — оценочные

mecounts <- apply(as.matrix(dtm[,c("я","мы")]), 1, sum)
hecounts <- apply(as.matrix(dtm[,c("он","она","они")]), 1, sum)
pastcounts <- apply(as.matrix(grammar[,c("прош")]), 1, sum)
fit.me <- lm(log(charlength) ~ log(mecounts+1))
fit.he <- lm(log(charlength) ~ log(hecounts+1))
fit.past <- lm(log(charlength) ~ log(pastcounts+1))

install.packages("stringr")
library(stringr)
exclamcounts <- str_count(src$Review, "!")
fit.exclam <- lm(log(charlength) ~ log(exclamcounts+1))

## подготовка таблицы с данными
features <- data.frame(sex = as.factor(src$Sex), sentclass = as.factor(sentclass), sentiment = sentresiduals, me = fit.me$residuals, he = fit.he$residuals, past = fit.past$residuals, exclam = fit.exclam$residuals)

## строим линейную регрессию, предсказывающую уровень оценочности
fit.sentiment <- lm (sentiment ~ sex + me + he + past + exclam, data=features)
summary(fit.sentiment)

