
R version 3.1.2 (2014-10-31) -- "Pumpkin Helmet"
Copyright (C) 2014 The R Foundation for Statistical Computing
Platform: x86_64-alt-linux-gnu (64-bit)

R is free software and comes with ABSOLUTELY NO WARRANTY.
You are welcome to redistribute it under certain conditions.
Type 'license()' or 'licence()' for distribution details.

R is a collaborative project with many contributors.
Type 'contributors()' for more information and
'citation()' on how to cite R or R packages in publications.

Type 'demo()' for some demos, 'help()' for on-line help, or
'help.start()' for an HTML browser interface to help.
Type 'q()' to quit R.

> options(STERM='iESS', str.dendrogram.last="'", editor='emacsclient', show.error.locations=TRUE)
> 
> + Installing package into ‘/home/kirill/R/x86_64-alt-linux-gnu-library/3.1’
(as ‘lib’ is unspecified)
--- Please select a CRAN mirror for use in this session ---
Error in contrib.url(repos, type) (from 00corpus.R#5) : 
  trying to use CRAN without setting a mirror
> 
> + Installing package into ‘/home/kirill/R/x86_64-alt-linux-gnu-library/3.1’
(as ‘lib’ is unspecified)
--- Please select a CRAN mirror for use in this session ---
trying URL 'http://mirrors.softliste.de/cran/src/contrib/tm_0.6-2.tar.gz'
Content type 'application/x-gzip' length 511060 bytes (499 Kb)
opened URL
==================================================
downloaded 499 Kb

* installing *source* package ‘tm’ ...
** package ‘tm’ successfully unpacked and MD5 sums checked
** libs
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c copy.c -o copy.o
x86_64-alt-linux-gcc -std=gnu99 -shared -L/usr/local/lib64 -o tm.so copy.o -L/usr/lib64/R/lib -lR
installing to /home/kirill/R/x86_64-alt-linux-gnu-library/3.1/tm/libs
** R
** data
** inst
** preparing package for lazy loading
** help
*** installing help indices
Warning in file.copy(file.path(R.home("doc"), "html", "R.css"), outman) :
  problem copying /usr/share/doc/R-3.1/html/R.css to /home/kirill/R/x86_64-alt-linux-gnu-library/3.1/tm/html/R.css: Нет такого файла или каталога
  converting help for package ‘tm’
    finding HTML links ... done
    Corpus                                  html  
    DataframeSource                         html  
    DirSource                               html  
    Docs                                    html  
    PCorpus                                 html  
    PlainTextDocument                       html  
Rd warning: /tmp/.private/kirill/RtmpAH1zg0/R.INSTALL78de7467db27/tm/man/PlainTextDocument.Rd:28: missing file link ‘parse_ISO_8601_datetime’
    Reader                                  html  
    Source                                  html  
    TextDocument                            html  
    finding level-2 HTML links ... done

    URISource                               html  
    VCorpus                                 html  
    VectorSource                            html  
    WeightFunction                          html  
    XMLSource                               html  
    XMLTextDocument                         html  
Rd warning: /tmp/.private/kirill/RtmpAH1zg0/R.INSTALL78de7467db27/tm/man/XMLTextDocument.Rd:27: missing file link ‘parse_ISO_8601_datetime’
    ZipSource                               html  
    Zipf_n_Heaps                            html  
    acq                                     html  
    combine                                 html  
    content_transformer                     html  
Rd warning: /tmp/.private/kirill/RtmpAH1zg0/R.INSTALL78de7467db27/tm/man/content_transformer.Rd:18: missing file link ‘content’
    crude                                   html  
    findAssocs                              html  
    findFreqTerms                           html  
    foreign                                 html  
Rd warning: /tmp/.private/kirill/RtmpAH1zg0/R.INSTALL78de7467db27/tm/man/foreign.Rd:45: missing file link ‘read_stm_MC’
    getTokenizers                           html  
    getTransformations                      html  
    inspect                                 html  
    matrix                                  html  
    meta                                    html  
Rd warning: /tmp/.private/kirill/RtmpAH1zg0/R.INSTALL78de7467db27/tm/man/meta.Rd:58: missing file link ‘meta’
    plot                                    html  
    readDOC                                 html  
    readPDF                                 html  
    readPlain                               html  
    readRCV1                                html  
    readReut21578XML                        html  
    readTabular                             html  
    readTagged                              html  
    readXML                                 html  
    removeNumbers                           html  
    removePunctuation                       html  
    removeSparseTerms                       html  
    removeWords                             html  
Rd warning: /tmp/.private/kirill/RtmpAH1zg0/R.INSTALL78de7467db27/tm/man/removeWords.Rd:25: missing file link ‘remove_stopwords’
    stemCompletion                          html  
    stemDocument                            html  
    stopwords                               html  
    stripWhitespace                         html  
    termFreq                                html  
Rd warning: /tmp/.private/kirill/RtmpAH1zg0/R.INSTALL78de7467db27/tm/man/termFreq.Rd:18: missing file link ‘Span_Tokenizer’
Rd warning: /tmp/.private/kirill/RtmpAH1zg0/R.INSTALL78de7467db27/tm/man/termFreq.Rd:19: missing file link ‘Token_Tokenizer’
    tm_filter                               html  
    tm_map                                  html  
    tm_reduce                               html  
    tm_term_score                           html  
    tokenizer                               html  
Rd warning: /tmp/.private/kirill/RtmpAH1zg0/R.INSTALL78de7467db27/tm/man/tokenizer.Rd:34: missing file link ‘Regexp_Tokenizer’
Rd warning: /tmp/.private/kirill/RtmpAH1zg0/R.INSTALL78de7467db27/tm/man/tokenizer.Rd:37: missing file link ‘tokenize’
    weightBin                               html  
    weightSMART                             html  
    weightTf                                html  
    weightTfIdf                             html  
    writeCorpus                             html  
** building package indices
** installing vignettes
** testing if installed package can be loaded
* DONE (tm)

The downloaded source packages are in
	‘/tmp/.private/kirill/Rtmpa79YKD/downloaded_packages’
Installing package into ‘/home/kirill/R/x86_64-alt-linux-gnu-library/3.1’
(as ‘lib’ is unspecified)
trying URL 'http://mirrors.softliste.de/cran/src/contrib/SnowballC_0.5.1.tar.gz'
Content type 'application/x-gzip' length 3044522 bytes (2.9 Mb)
opened URL
==================================================
downloaded 2.9 Mb

* installing *source* package ‘SnowballC’ ...
** package ‘SnowballC’ successfully unpacked and MD5 sums checked
** libs
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c api.c -o api.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c libstemmer_utf8.c -o libstemmer_utf8.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem.c -o stem.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_danish.c -o stem_UTF_8_danish.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_dutch.c -o stem_UTF_8_dutch.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_english.c -o stem_UTF_8_english.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_finnish.c -o stem_UTF_8_finnish.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_french.c -o stem_UTF_8_french.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_german.c -o stem_UTF_8_german.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_hungarian.c -o stem_UTF_8_hungarian.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_italian.c -o stem_UTF_8_italian.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_norwegian.c -o stem_UTF_8_norwegian.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_porter.c -o stem_UTF_8_porter.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_portuguese.c -o stem_UTF_8_portuguese.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_romanian.c -o stem_UTF_8_romanian.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_russian.c -o stem_UTF_8_russian.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_spanish.c -o stem_UTF_8_spanish.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_swedish.c -o stem_UTF_8_swedish.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_turkish.c -o stem_UTF_8_turkish.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c utilities.c -o utilities.o
x86_64-alt-linux-gcc -std=gnu99 -shared -L/usr/local/lib64 -o SnowballC.so api.o libstemmer_utf8.o stem.o stem_UTF_8_danish.o stem_UTF_8_dutch.o stem_UTF_8_english.o stem_UTF_8_finnish.o stem_UTF_8_french.o stem_UTF_8_german.o stem_UTF_8_hungarian.o stem_UTF_8_italian.o stem_UTF_8_norwegian.o stem_UTF_8_porter.o stem_UTF_8_portuguese.o stem_UTF_8_romanian.o stem_UTF_8_russian.o stem_UTF_8_spanish.o stem_UTF_8_swedish.o stem_UTF_8_turkish.o utilities.o -L/usr/lib64/R/lib -lR
installing to /home/kirill/R/x86_64-alt-linux-gnu-library/3.1/SnowballC/libs
** R
** inst
** preparing package for lazy loading
** help
*** installing help indices
Warning in file.copy(file.path(R.home("doc"), "html", "R.css"), outman) :
  problem copying /usr/share/doc/R-3.1/html/R.css to /home/kirill/R/x86_64-alt-linux-gnu-library/3.1/SnowballC/html/R.css: Нет такого файла или каталога
  converting help for package ‘SnowballC’
    finding HTML links ... done
    getStemLanguages                        html  
    wordStem                                html  
** building package indices
** testing if installed package can be loaded
* DONE (SnowballC)

The downloaded source packages are in
	‘/tmp/.private/kirill/Rtmpa79YKD/downloaded_packages’
Loading required package: NLP
Error in file(file, "rt") (from 00corpus.R#15) : cannot open the connection
In addition: Warning message:
In file(file, "rt") :
  cannot open file 'school.csv': Нет такого файла или каталога
> install.packages("tm")
Installing package into ‘/home/kirill/R/x86_64-alt-linux-gnu-library/3.1’
(as ‘lib’ is unspecified)
trying URL 'http://mirrors.softliste.de/cran/src/contrib/tm_0.6-2.tar.gz'
Content type 'application/x-gzip' length 511060 bytes (499 Kb)
opened URL
==================================================
downloaded 499 Kb

* installing *source* package ‘tm’ ...
** package ‘tm’ successfully unpacked and MD5 sums checked
** libs
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c copy.c -o copy.o
x86_64-alt-linux-gcc -std=gnu99 -shared -L/usr/local/lib64 -o tm.so copy.o -L/usr/lib64/R/lib -lR
installing to /home/kirill/R/x86_64-alt-linux-gnu-library/3.1/tm/libs
** R
** data
** inst
** preparing package for lazy loading
** help
*** installing help indices
Warning in file.copy(file.path(R.home("doc"), "html", "R.css"), outman) :
  problem copying /usr/share/doc/R-3.1/html/R.css to /home/kirill/R/x86_64-alt-linux-gnu-library/3.1/tm/html/R.css: Нет такого файла или каталога
  converting help for package ‘tm’
    finding HTML links ... done
    Corpus                                  html  
    DataframeSource                         html  
    DirSource                               html  
    Docs                                    html  
    PCorpus                                 html  
    PlainTextDocument                       html  
Rd warning: /tmp/.private/kirill/RtmpWM09Em/R.INSTALL79586a018016/tm/man/PlainTextDocument.Rd:28: missing file link ‘parse_ISO_8601_datetime’
    Reader                                  html  
    Source                                  html  
    TextDocument                            html  
    finding level-2 HTML links ... done

    URISource                               html  
    VCorpus                                 html  
    VectorSource                            html  
    WeightFunction                          html  
    XMLSource                               html  
    XMLTextDocument                         html  
Rd warning: /tmp/.private/kirill/RtmpWM09Em/R.INSTALL79586a018016/tm/man/XMLTextDocument.Rd:27: missing file link ‘parse_ISO_8601_datetime’
    ZipSource                               html  
    Zipf_n_Heaps                            html  
    acq                                     html  
    combine                                 html  
    content_transformer                     html  
Rd warning: /tmp/.private/kirill/RtmpWM09Em/R.INSTALL79586a018016/tm/man/content_transformer.Rd:18: missing file link ‘content’
    crude                                   html  
    findAssocs                              html  
    findFreqTerms                           html  
    foreign                                 html  
Rd warning: /tmp/.private/kirill/RtmpWM09Em/R.INSTALL79586a018016/tm/man/foreign.Rd:45: missing file link ‘read_stm_MC’
    getTokenizers                           html  
    getTransformations                      html  
    inspect                                 html  
    matrix                                  html  
    meta                                    html  
Rd warning: /tmp/.private/kirill/RtmpWM09Em/R.INSTALL79586a018016/tm/man/meta.Rd:58: missing file link ‘meta’
    plot                                    html  
    readDOC                                 html  
    readPDF                                 html  
    readPlain                               html  
    readRCV1                                html  
    readReut21578XML                        html  
    readTabular                             html  
    readTagged                              html  
    readXML                                 html  
    removeNumbers                           html  
    removePunctuation                       html  
    removeSparseTerms                       html  
    removeWords                             html  
Rd warning: /tmp/.private/kirill/RtmpWM09Em/R.INSTALL79586a018016/tm/man/removeWords.Rd:25: missing file link ‘remove_stopwords’
    stemCompletion                          html  
    stemDocument                            html  
    stopwords                               html  
    stripWhitespace                         html  
    termFreq                                html  
Rd warning: /tmp/.private/kirill/RtmpWM09Em/R.INSTALL79586a018016/tm/man/termFreq.Rd:18: missing file link ‘Span_Tokenizer’
Rd warning: /tmp/.private/kirill/RtmpWM09Em/R.INSTALL79586a018016/tm/man/termFreq.Rd:19: missing file link ‘Token_Tokenizer’
    tm_filter                               html  
    tm_map                                  html  
    tm_reduce                               html  
    tm_term_score                           html  
    tokenizer                               html  
Rd warning: /tmp/.private/kirill/RtmpWM09Em/R.INSTALL79586a018016/tm/man/tokenizer.Rd:34: missing file link ‘Regexp_Tokenizer’
Rd warning: /tmp/.private/kirill/RtmpWM09Em/R.INSTALL79586a018016/tm/man/tokenizer.Rd:37: missing file link ‘tokenize’
    weightBin                               html  
    weightSMART                             html  
    weightTf                                html  
    weightTfIdf                             html  
    writeCorpus                             html  
** building package indices
** installing vignettes
** testing if installed package can be loaded
* DONE (tm)

The downloaded source packages are in
	‘/tmp/.private/kirill/Rtmpa79YKD/downloaded_packages’
> install.packages("SnowballC")
Installing package into ‘/home/kirill/R/x86_64-alt-linux-gnu-library/3.1’
(as ‘lib’ is unspecified)
trying URL 'http://mirrors.softliste.de/cran/src/contrib/SnowballC_0.5.1.tar.gz'
Content type 'application/x-gzip' length 3044522 bytes (2.9 Mb)
opened URL
==================================================
downloaded 2.9 Mb

* installing *source* package ‘SnowballC’ ...
** package ‘SnowballC’ successfully unpacked and MD5 sums checked
** libs
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c api.c -o api.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c libstemmer_utf8.c -o libstemmer_utf8.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem.c -o stem.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_danish.c -o stem_UTF_8_danish.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_dutch.c -o stem_UTF_8_dutch.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_english.c -o stem_UTF_8_english.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_finnish.c -o stem_UTF_8_finnish.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_french.c -o stem_UTF_8_french.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_german.c -o stem_UTF_8_german.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_hungarian.c -o stem_UTF_8_hungarian.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_italian.c -o stem_UTF_8_italian.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_norwegian.c -o stem_UTF_8_norwegian.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_porter.c -o stem_UTF_8_porter.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_portuguese.c -o stem_UTF_8_portuguese.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_romanian.c -o stem_UTF_8_romanian.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_russian.c -o stem_UTF_8_russian.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_spanish.c -o stem_UTF_8_spanish.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_swedish.c -o stem_UTF_8_swedish.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c stem_UTF_8_turkish.c -o stem_UTF_8_turkish.o
x86_64-alt-linux-gcc -std=gnu99 -I/usr/include/R -DNDEBUG  -I/usr/local/include    -fpic  -pipe -Wall -g -O2 -fno-strict-aliasing  -c utilities.c -o utilities.o
x86_64-alt-linux-gcc -std=gnu99 -shared -L/usr/local/lib64 -o SnowballC.so api.o libstemmer_utf8.o stem.o stem_UTF_8_danish.o stem_UTF_8_dutch.o stem_UTF_8_english.o stem_UTF_8_finnish.o stem_UTF_8_french.o stem_UTF_8_german.o stem_UTF_8_hungarian.o stem_UTF_8_italian.o stem_UTF_8_norwegian.o stem_UTF_8_porter.o stem_UTF_8_portuguese.o stem_UTF_8_romanian.o stem_UTF_8_russian.o stem_UTF_8_spanish.o stem_UTF_8_swedish.o stem_UTF_8_turkish.o utilities.o -L/usr/lib64/R/lib -lR
installing to /home/kirill/R/x86_64-alt-linux-gnu-library/3.1/SnowballC/libs
** R
** inst
** preparing package for lazy loading
** help
*** installing help indices
Warning in file.copy(file.path(R.home("doc"), "html", "R.css"), outman) :
  problem copying /usr/share/doc/R-3.1/html/R.css to /home/kirill/R/x86_64-alt-linux-gnu-library/3.1/SnowballC/html/R.css: Нет такого файла или каталога
  converting help for package ‘SnowballC’
    finding HTML links ... done
    getStemLanguages                        html  
    wordStem                                html  
** building package indices
** testing if installed package can be loaded
* DONE (SnowballC)

The downloaded source packages are in
	‘/tmp/.private/kirill/Rtmpa79YKD/downloaded_packages’
> library(tm)
> library(SnowballC)
> # Вариант 1: тексты в .csv-файле
> collection<-read.table("school.csv",sep="\t", header=T, stringsAsFactors=F, encoding="UTF-8") # загружаем файл в data.frame
Error in file(file, "rt") : cannot open the connection
In addition: Warning message:
In file(file, "rt") :
  cannot open file 'school.csv': Нет такого файла или каталога
> corp<-Corpus(VectorSource(collection$text), readerControl=list(language="ru", encoding="UTF-8")) # берем тексты из колонки "text"
Error in SimpleSource(length = length(x), content = x, class = "VectorSource") : 
  object 'collection' not found
> corp<-tm_map(corp, content_transformer(tolower)) # приведение к нижнему регистру
Error in tm_map(corp, content_transformer(tolower)) : 
  object 'corp' not found
> freqlist.df <- data.frame(word=names(freqlist), freq=freqlist)
Error in data.frame(word = names(freqlist), freq = freqlist) : 
  object 'freqlist' not found
> freqlist.df <- data.frame(word=names(freqlist), freq=freqlist)
Error in data.frame(word = names(freqlist), freq = freqlist) : 
  object 'freqlist' not found
> ?package.contents
> help(package="tm")

		Information on package ‘tm’

Description:

Package:                   tm
Title:                     Text Mining Package
Version:                   0.6-2
Date:                      2015-07-02
Authors@R:                 c(person("Ingo", "Feinerer", role = c("aut",
                           "cre"), email = "feinerer@logic.at"),
                           person("Kurt", "Hornik", role = "aut"),
                           person("Artifex Software, Inc.", role =
                           c("ctb", "cph"), comment = "pdf_info.ps
                           taken from GPL Ghostscript"))
Depends:                   R (>= 3.1.0), NLP (>= 0.1-6.2)
Imports:                   parallel, slam (>= 0.1-31), stats, tools,
                           utils, graphics
Suggests:                  filehash, methods, Rcampdf, Rgraphviz,
                           Rpoppler, SnowballC,
                           tm.lexicon.GeneralInquirer, XML
SystemRequirements:        Antiword (<http://www.winfield.demon.nl/>)
                           for reading MS Word files, pdfinfo and
                           pdftotext from Poppler
                           (<http://poppler.freedesktop.org/>) for
                           reading PDF
Description:               A framework for text mining applications
                           within R.
License:                   GPL-3
URL:                       http://tm.r-forge.r-project.org/
Additional_repositories:   http://datacube.wu.ac.at
NeedsCompilation:          yes
Packaged:                  2015-07-03 06:57:05 UTC; hornik
Author:                    Ingo Feinerer [aut, cre], Kurt Hornik [aut],
                           Artifex Software, Inc. [ctb, cph]
                           (pdf_info.ps taken from GPL Ghostscript)
Maintainer:                Ingo Feinerer <feinerer@logic.at>
Repository:                CRAN
Date/Publication:          2015-07-03 10:43:07
Built:                     R 3.1.2; x86_64-alt-linux-gnu; 2015-09-06
                           19:19:43 UTC; unix

Index:

Corpus                  Corpora
DataframeSource         Data Frame Source
DirSource               Directory Source
Docs                    Access Document IDs and Terms
MC_tokenizer            Tokenizers
PCorpus                 Permanent Corpora
PlainTextDocument       Plain Text Documents
Reader                  Readers
Source                  Sources
TermDocumentMatrix      Term-Document Matrix
TextDocument            Text Documents
URISource               Uniform Resource Identifier Source
VCorpus                 Volatile Corpora
VectorSource            Vector Source
WeightFunction          Weighting Function
XMLSource               XML Source
XMLTextDocument         XML Text Documents
ZipSource               ZIP File Source
Zipf_plot               Explore Corpus Term Frequency Characteristics
acq                     50 Exemplary News Articles from the
                        Reuters-21578 Data Set of Topic acq
c.VCorpus               Combine Corpora, Documents, Term-Document
                        Matrices, and Term Frequency Vectors
content_transformer     Content Transformers
crude                   20 Exemplary News Articles from the
                        Reuters-21578 Data Set of Topic crude
findAssocs              Find Associations in a Term-Document Matrix
findFreqTerms           Find Frequent Terms
getTokenizers           Tokenizers
getTransformations      Transformations
inspect                 Inspect Objects
meta                    Metadata Management
plot.TermDocumentMatrix
                        Visualize a Term-Document Matrix
readDOC                 Read In a MS Word Document
readPDF                 Read In a PDF Document
readPlain               Read In a Text Document
readRCV1                Read In a Reuters Corpus Volume 1 Document
readReut21578XML        Read In a Reuters-21578 XML Document
readTabular             Read In a Text Document
readTagged              Read In a POS-Tagged Word Text Document
readXML                 Read In an XML Document
read_dtm_Blei_et_al     Read Document-Term Matrices
removeNumbers           Remove Numbers from a Text Document
removePunctuation       Remove Punctuation Marks from a Text Document
removeSparseTerms       Remove Sparse Terms from a Term-Document Matrix
removeWords             Remove Words from a Text Document
stemCompletion          Complete Stems
stemDocument            Stem Words
stopwords               Stopwords
stripWhitespace         Strip Whitespace from a Text Document
termFreq                Term Frequency Vector
tm_filter               Filter and Index Functions on Corpora
tm_map                  Transformations on Corpora
tm_reduce               Combine Transformations
tm_term_score           Compute Score for Matching Terms
weightBin               Weight Binary
weightSMART             SMART Weightings
weightTf                Weight by Term Frequency
weightTfIdf             Weight by Term Frequency - Inverse Document
                        Frequency
writeCorpus             Write a Corpus to Disk

Further information is available in the following vignettes in
directory ‘/home/kirill/R/x86_64-alt-linux-gnu-library/3.1/tm/doc’:

extensions: Extensions (source, pdf)
tm: Introduction to the tm Package (source, pdf)

> getTokenizers()
[1] "MC_tokenizer"   "scan_tokenizer"
> ?MC_tokenizer
> ?Regexp_Tokenizer
> 