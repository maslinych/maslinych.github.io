vovochka<-slam::row_sums(dtm[,c("вов","вовочк")])>0
labels <- as.factor(vovochka)
dtm<-dtm[,-which(Terms(dtm) %in% c("вов", "вовочк"))]
