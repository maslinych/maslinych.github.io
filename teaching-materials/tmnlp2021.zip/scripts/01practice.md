## 01. Lexical statistics. Exercises

1.0 [1] Load the data from the Harry Potter series (see them posted in our
course's channel).

1.1 [1] Perform simple word tokenization for all the text. Keep the
tokenized data in tidy (long) format. 

1.2 [1] Compile a word frequency list for Harry Potter data. Make a plot
word rank — word frequency, both in the original and in the
logarithmic scale. 

1.4 [2] What would be the frequency predicted by Zipf's law for the second
and third words in the frequency list for Harry Potter data? How this
frequency relates to actual frequency in the data?

1.5 [1] What is the average and median word frequency in Harry Potter's
data? How will they change if we take only the first half of data as
our corpus? Explain why. 

1.6 [2] If we doubled the amount of text taken from Harry Potter as our
data, how much the size of the vocabulary would increase? Give your
estimate in percentage points.

1.7 [2] Estimate the Baayen G (vocabulary growth rate) for the Harry
Potter data.  Plot the change in this value for each of
44 fragments of text. 

## The second word should appear twice as often as the third one, but in our data this is not true. The frequency of the second one is 563, while of the third - 488. 
