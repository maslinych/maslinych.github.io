1.4. The total number of different words is not the good estimate for
C in the Zipf's law formula — it's obvously too high. A much better
guess would be to take the frequency of the most frequent word as C
(C/1 = f(rank_1_word_frequency)).


Погодина

An excellent work! One thing I didn't quite get is the logic of your
solution to 1.7. Why i += 518 exactly? One more notice is that the
Baayen G is defined as a number of words that were encountered only
once by that point (hapax legomena) divided by the number of tokens.
Thus the relationship of the size of the lexicon to the number of
tokens is a related, but a different thing. 


Саматов

Yaroslav, good work. Some discussion and hints: 
1.2. My bet is that the problem with the punctuation that's left in the requency list is a side-effect of using stopwords as a global variable (as we discussed in the last class), not in the preprocessing function itself. You had something incorrect in stopwords when the preprocess was executed. 
1.4. You can actually estimate Zipf's predictions more precisely, if you take the freq. of the most frequent word as C, then the freq of the 2nd will e C/2, 3d C/3 etc.
1.5. Wrong answer, because you have only top-30 rows in your freq_table df, not the whole frequency list. Double check!
1.6. A decent estimate, and well argued. But note, that there was a formula in the slides that lets you estimate that more precisely.
1.7. I'm of little help to debug plotting problems here (use R myself, you know:) , but the thind that you was going to plot is related to the problem in question, but not exactly what was expected. Bayyaen G is a ratio V(1)/N.
