## 02. Comparing corpora. Exercises

3.1. Download dataset with Shakespeare's works (posted on
MsTeams). Load all the texts into python objects (lists of
strings). You may use a script regex.py [posted on Telegram] as a
sample of how this could be done. All the following excercises assume
that you work with this collection.

3.2. Remove marks indicating speaker turns (character names) from ииthe
texts using regular expressions. [regex.py may help you again]

3.3. Perform tokenization and optionally lemmatization of texts.

3.4. Select "Macbeth" as a focal corpus and all other works of
Shakespeare as a reference corpus. Compute normalized frequencies 
(IPM, instances per million) for all the words that occur in both
corpora. Select words that are the most typical of "Macbeth" using the
“simple maths” method of Adam Kilgariff. How does the list of such
words change when you use add +100 constant to the original words'
frequencies in simple maths method? How does the result change when
you limit your scope to only those words that occurred 100 and more
times in total in the original corpus?

3.5. Repeat contrast analysis from Exercise 3.4, this time using
the Dunning's log-likelihood ratio to select the words with the most
skewed distribution across the two contrasting corpora. Please note
that log-likelihood is a symmetric measure, and it may show both more
frequent and less frequent lexical items in Macbeth on top of the
list. In what respect are the results similar, and how do they differ
from the results of the previous exercise?

3.6. Select the words that are the most characteristic of Macbeth
using the log-odds ratio. Are these results similar to either
log-likelihood or simple maths? Why or why not?

3.7. The authors of one article on wierd stylistics of Macbeth
(http://maslinsky.spb.ru/courses/cmta2021/reader/The_language_of_Macbeth.pdf)
attach great importance to the increased frequency of a definite
article in Macbeth that they found compared to Shakespeare's work as a
whole.  Can we say that this is indeed a stylistic feature of Macbeth?
Compare the relative frequency of the definite article in different
works of Shakespeare with its frequency in Macbeth. What conclusions
can be drawn from such a comparison?
