#!/usr/bin/env python
# coding: utf-8

# 3.1. Download dataset with Shakespeare's works (posted on
# MsTeams). Load all the texts into python objects (lists of
# strings). You may use a script regex.py [posted on Telegram] as a
# sample of how this could be done. All the following excercises assume
# that you work with this collection.

def tokenize(text):
    """simplistic tokenizer str -> [str]"""
    text = text.lower()
    tokens = str.split(text, ' ')
    return tokens

s1 = 'Once upon a time there lived a Hobbot in a hole.'

toks = tokenize(s1)

import os
import re
import sys


def read_txt(filename):
    """read a text file into a list of lines str -> [str]"""
    with open(filename, 'r') as f:
        try:
            lines = []
            for line in f:
                lines.append(line.strip())
        except(UnicodeDecodeError):
            print("Unicode decode error:", filename)
            return []
    return lines

def read_data(datadir):
    """read all text files from a directory into lists of strings str -> [[str]]"""
    files = os.listdir(datadir)
    plays = []
    for f in files:
        plays.append(read_txt(os.path.join(datadir, f)))
    return plays

plays = read_data("data/shakespeare")

# 3.2. Remove marks indicating speaker turns (character names) from ииthe
# texts using regular expressions. [regex.py may help you again]


def remove_characters(line):
    return re.sub("^([A-Z]+\\b ?)+", '', line)

cleanplays = []
for play in plays:
    cleanlines = []
    for line in play:
        cleanlines.append(remove_characters(line))
    cleanplays.append(cleanlines)

import pandas as pd

plays_df = pd.DataFrame({'text':cleanplays})

# 3.3. Perform tokenization and optionally lemmatization of texts.

import re

def tokenize_text(text):
    """tokenize a list of strings  [str] -> [[str]]"""
    out = []
    for line in text:
        toks = tokenize_re(line)
        out.extend(toks)
    return out

def tokenize_re(text):
    """not so simplistic tokenizer str -> [str]"""
    text = text.lower()
    tokens = list(filter(None, re.split('\W+', text)))
    return tokens

tokenize_re(s1)

plays_df['text'].apply(tokenize_text).to_frame(name='tokens').head()

def detect_macbeth(title):
    if title == "Macbeth":
        return 'macbeth'
    else:
        return 'other'

df = (plays_df
      .assign(tokens = lambda x: x.text.apply(tokenize_text))
      .assign(title = lambda x: x.text.apply(lambda l: l[0]))
      .assign(corpus = lambda x: x.title.apply(detect_macbeth))
)

## extract titles


# 3.4. Select "Macbeth" as a focal corpus and all other works of
# Shakespeare as a reference corpus. Compute normalized frequencies 
# (IPM, instances per million) for all the words that occur in both
# corpora. Select words that are the most typical of "Macbeth" using the
# “simple maths” method of Adam Kilgariff. How does the list of such
# words change when you use add +100 constant to the original words'
# frequencies in simple maths method? How does the result change when
# you limit your scope to only those words that occurred 100 and more
# times in total in the original corpus?

df_long = df[['corpus', 'tokens']].explode('tokens')

df_wordcounts = (df_long.groupby(['corpus', 'tokens'])[['tokens']]
                 .count()['tokens']
                 .sort_values(ascending=False)
                 .to_frame('n')
                 .reset_index()
)

df_ipm = (df_wordcounts
          .assign(ipm = df_wordcounts
                  .groupby('corpus')['n']
                  .apply(lambda x: x/sum(x)*1e6))
)

both_ipm = (df_ipm
            .pivot(index='tokens', columns='corpus', values='ipm')
            .reset_index()
            .fillna(0))

(both_ipm.query('other > 50 & macbeth > 0')
 .assign(sm = lambda x: x.macbeth/x.other)
 .sort_values(by='sm', ascending=False))

both_ipm.query('other > 0 & macbeth > 0').assign(sm = lambda x: x.macbeth/x.other)


df_wordcounts.assign(n100 = lambda x: x.n+100)

# 3.5. Repeat contrast analysis from Exercise 3.4, this time using
# the Dunning's log-likelihood ratio to select the words with the most
# skewed distribution across the two contrasting corpora. Please note
# that log-likelihood is a symmetric measure, and it may show both more
# frequent and less frequent lexical items in Macbeth on top of the
# list. In what respect are the results similar, and how do they differ
# from the results of the previous exercise?


import numpy as np

def g2(a, b):
    """calculate log likelihood for two columns of frequencies"""
    c = a.sum()
    d = b.sum()
    
    E1 = c * ((a + b) / (c + d))
    E2 = d * ((a + b) / (c + d))
    
    return 2*((a*np.log(a/E1+1e-7)) + (b*np.log(b/E2+1e-7)))


both_g2 = (df_wordcounts
            .pivot(index='tokens', columns='corpus', values='n')
            .reset_index()
            .fillna(0)
            .assign(g2 = lambda x: g2(x.macbeth, x.other))
            .sort_values(by='g2', ascending=False)
)

both_g2.join(both_ipm, rsuffix='.ipm').query('other > 50')
