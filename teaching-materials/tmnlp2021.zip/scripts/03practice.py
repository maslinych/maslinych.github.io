#!/usr/bin/env python

# 3.1. Load Shakesperean data as a pandas dataframe. Make a column
# containing a list of play titles. Hint: first line of each file
# contains a title.

# 3.2. Annotate each play with its corresponing genre using data from
# the genres dict listed below. Keep genre info in a separate colum of
# a dataframe.

genres = {
    'comedy': [
        "All's Well That Ends Well",
        "As You Like It",
        "Comedy of Errors",
        "Love's Labour's Lost",
        "Measure for Measure",
        "Merchant of Venice",
        "Merry Wives of Windsor",
        "Midsummer Night's Dream",
        "Much Ado about Nothing",
        "Taming of the Shrew",
        "Tempest",
        "Twelfth Night",
        "Two Gentlemen of Verona",
        "Winter's Tale"],
    'history': [
        "Henry IV, Part I",
        "Henry IV, Part II",
        "Henry V",
        "Henry VI, Part I",
        "Henry VI, Part II",
        "Henry VI, Part III",
        "Henry VIII",
        "King John",
        "Pericles",
        "Richard II",
        "Richard III" ],
    'tragedy': [
        "Antony and Cleopatra",
        "Coriolanus",
        "Cymbeline",
        "Hamlet",
        "Julius Caesar",
        "King Lear",
        "Macbeth",
        "Othello",
        "Romeo and Juliet",
        "Timon of Athens",
        "Titus Andronicus",
        "Troilus and Cressida"]
    }

## 3.3. Perform tokenization and preprocessing cleanup of the
## texts. Remove speaker labels, numbers, punctuation,
## stopwords. Consider using not a standard list of stopwords, but a
## list of k top-frequent words in the Skakespearean corpus. Why the
## "standard" list for English provided in nltk may be inappropriate
## for these data?

## 3.4. Calculate normalized word frequency (IPM) for each of the genres.

## 3.5. Rates of what words are the most different in comedies and
## tragedies if compared using simple maths method of Adam Kilgariff?
## Limit the scope only to those words that have non-zero frequency in
## both corpora. How does the list of such words change when you use
## add +100 constant to the original words' frequencies in simple
## maths method? How does the result change when you limit your scope
## to only those words that occurred 100 and more times in total in
## the original corpus?

## 3.6. Repeat contrast analysis from Exercise 3.5, this time using
## the Dunning's log-likelihood ratio to select the words with the most
## skewed distribution across the two contrasting corpora. Please note
## that log-likelihood is a symmetric measure, and it may show both more
## frequent and less frequent lexical items in Macbeth on top of the
## list. In what respect are the results similar, and how do they differ
## from the results of the previous exercise?

## 3.7.  Select the words that are the most characteristic of comedies
## and tragedies using the log-odds ratio. Are these results similar
## to either log-likelihood or simple maths? Why or why not?

## 3.8.* Can you generalize the log-likelyhood formula to a
## three-class case so that it can highlight those words frequency
## rates of which are maximally skewed across all three genres?
