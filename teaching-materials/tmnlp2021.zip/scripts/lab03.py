# -*- coding: utf-8 -*-
"""3.1. Download a dataset on the works of Shakespeare. Perform lemmatization (with the help of mystem) and
tokenization of texts.
"""



"""3.2. Select "Macbeth" and perform a contrast analysis of the vocabulary of the play against the vocabulary of all other works included in the dataset using the simple maths approach by Adam Kilgarriff (+n). Use 1, 10, 100 as constants to add to the frequency.

How does the list of the most characteristic words of Shakespeare change when the constant increases?
"""



"""3.3. Repeat the contrast analysis from Exercise 3.2, this time using the log-likelihood ratio by Dunning to measure the significance of differences. Please note that log-likelihood is a symmetric measure, and it shows both significantly more frequent and less frequent lexical units for Shakespeare. 

How are the results similar, and how do they differ from the results of the previous exercise?
"""



"""3.4. Check the influence of the preprocessing parameters on the results of the contrast analysis of the vocabulary of Shakespeare and their potential impact on the conclusions from such an analysis. To do this, conduct a series of experiments to calculate log-likelihood with different preprocessing parameters. Try to change the following parameters:

* presence/absence of lemmatization;
* deleting/saving stop words;
* static stopwords list stopwords("ru") / dynamic list stop words (top of the frequency list);
* presence/absence of a frequency cut-off threshold.

It is necessary to form at least three different combinations of the above parameters, perform text processing with the selected set of parameters and compare the results of contrast analysis. How much do the results change?
"""



"""3.5. Repeat the contrast analysis of the vocabulary of Shakespeare, but limit the consideration to adjectives only. 

Does this approach provide new information about the specifics of the style and content of the  texts of the poet?
"""



"""3.6.* The authors of the article on which the example given in the lecture about the creepy stylistics of Macbeth is based attach great importance to the increased frequency of a definite article in Macbeth that they found compared to Shakespeare's work as a whole. 

Can we say that this is a stylistic feature of Macbeth? Compare the relative frequency of the definite article in different works of Shakespeare with its frequency in Macbeth. What conclusions can be drawn from such a comparison?
"""