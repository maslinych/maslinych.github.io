#!/usr/bin/env python
# coding: utf-8

# # Text into Data
# 
# Author: Kirill Maslinsky
# 
# Python translation: Sergei Pashakhin

# Text mining tasks usually deal with a large number of text fragments: e. g. tweets, news, reviews etc. Having obtained these kind of data, we commonly have them in a table format with one of the columns containing text data, one at a line. Other columns typically contain some metadata about the text: author, title, date etc.
# 
# Our today's example is a collection of State of Union addresses yearly given by the US president since 18th century till 2018. The source of data: https://github.com/BrianWeinstein/state-of-the-union

# In[368]:


import pandas as pd
import numpy as np
import string
import re
import matplotlib.pyplot as plt


# In[369]:


sou = pd.read_csv("https://github.com/BrianWeinstein/state-of-the-union/blob/master/transcripts.csv?raw=true")


# In[370]:


sou.head()


# In[371]:


sou.info()


# One line in a table corresponds to a president's speech. Texts are located in the transcript column.
# 
# Our ultimate goal is to use information contained in the texts as variable(s) to include in our models and hypothesis testing. This means that we should be able to apply simple mathematical operations to texts. For instance, what text is “greater” in some sense? How to measure and compare distance between texts?
# 
# The key to the solution is to split the text into some simple units which can be easily compared… yes, words.
# 
# Still, to work with it as with data, we need to have the split text also in a table form. There are two useful formats to do that:
# 
#    * **long format** — a line in a table is created for each word in a text.
#    * **wide format** — a column is created for each word, a line corresponds to a single text.
# 
# We start with a long format.

# In[382]:


from nltk import word_tokenize  # a widely-used tokenizer that will ask you to download some resources

sou_long = sou[['president']]  # save meta-data for further analysis
sou_long['txt_tokens'] = sou['transcript'].apply(word_tokenize)


# In[384]:


sou_long['txt_tokens'][0][0:35]  # let's look at the first 34 tokens of the first speech


# Now, we are intersted only in words. The `preprocess` function will help us to achieve exactly that. This is will be our *utility function* that will document and organize our data cleaning procedure. We will discuss it a bit later.

# In[386]:


stopwords = list(string.punctuation + string.digits + ' ')  # combine all digits and punctuation characters
stopwords = set(stopwords)  # Remember: set() is faster than list() ! 


def preprocess(txt_token):
    clean = []  # a container for the cleaned data
    for token in txt_token:
        if token.lower() not in stopwords:  # excludes tokens that are in our stopword-set
            token = re.sub(r'[^a-zA-Z]', "", token.lower())  # exclude punctiation and digits from tokens
            if token != "":  # exclude empty tokens without information--byproduct of cleaning
                clean.append(token)
    return clean


# In[387]:


sou_long['words'] = sou_long['txt_tokens'].apply(preprocess)  # let's keep the original tokens
sou_long


# In[388]:


sou_long.info()


# In[389]:


# going tidy with Python
sou_long = sou_tokenized.explode('words')
sou_long


# Tokens are units of text, words in our case. Characters, sentences, word sequences (n-grams) may also serve as tokens for some tasks.

# # Frequency
# 
# Now we have a words column in our table. Technically, it is a categorical variable with as many values as there are distinct words in all the texts.

# In[390]:


sou_long['words'].unique().size  # quite a lot!


# Too much words to inspect. Let's have a glance at the most frequent ones, they should be the most informative, shouldn't they?

# In[391]:


(sou_long
 .groupby('words')
 ['words'].count()
 .sort_values(ascending=False)
 .to_frame(name='count').reset_index()
 .loc[0:15]
 .plot(kind='barh', 
       x='words', y="count") )


# Not very informative. Well, how the distribution looks like?

# # Lexical statistics. Zipf's law

# In[392]:


(sou_long
 .groupby('words')
 ['words'].count()
 .sort_values(ascending=False)
 .to_frame(name='count').reset_index()
 .plot(y='count', x='words') )


# Long-tail distribution (power law). Few giants, many dwarfs.
# 
# It was empirically observed that for any large enough collection of texts the distribution of word frequencies is almost log-linear.

# In[393]:

vocab_size = int(sou_long['words'].unique().size)

(sou_long
 .groupby('words')
 ['words'].count()
 .sort_values(ascending=False)
 .to_frame(name='count').reset_index()
 .sort_values('count', ascending=False)
 .assign(rank=range(1, vocab_size+1))[['rank', 'count']]
 .apply(np.log10).plot(x='rank', y='count') )


# This observation is called *Zipf's law*.

# # Stopwords
# 
# The most frequent words in any language — prepositions, conjunctions, pronouns — have the most abstract meaning. If we are interested in analysing content of the texts, they are not informative to us. Let's try to get rid of them.
# 
# The list of these grammatical words for English and other languages may be found in the stopwords package.

# In[394]:


# do you remember our utility function for preprocessing
# that relies on the variable 'stowords'?
# we will develop it further with real stopwords

# first, we will need a pre-made list of the most common stopwords in English
from nltk.corpus import stopwords
# nltk.download('stopwords')  # you have to download an additional resource when you are using it for the 1st time

stopwords.words('english')[0:15]  # here's the list of stopwords for English


# We have already seen a very similar list…

# In[395]:


top175words = (sou_long.groupby('words')
               ['words'].count()
               .sort_values(ascending=False)
               .to_frame(name='count').reset_index()
               .loc[0:175])
top175words['words'].head(35)


# In[398]:


top175words[~top175words['words'].isin(stopwords.words('english'))].words.values


# Let's eliminate stopwords from the text and look what is left. 

# In[399]:


sou_nonstop = sou_long[~sou_long['words'].isin(stopwords.words('english'))]


# What percentage of total text volume has been removed?

# **Take Home Task**
# 
# * Edit the `preprocess` function we created earlier to make it remove stopwords, digits and puctuation.
# 
# *Hint*: look into lists we use...

# # Wordcloud
# 
# Now we are going to represent the list of the most frequent words as a word cloud.

# In[400]:


from wordcloud import WordCloud  # install from conda-forge: 'conda install -c conda-forge wordcloud'
import matplotlib.pyplot as plt  # we need mathplotlib to show the wordcloud in a notebook
matplotlib.pyplot.ion()

plot_data = (sou_nonstop.groupby('words')  # 1) count and sort words
             ['words'].count()
             .sort_values(ascending=False)  
             .to_frame(name='count')  # 2) make a dictionary {word:frequency}
             .to_dict()['count'] )

# use WordCloud to plot our data
wc = WordCloud(width=800, height=400,
               max_words=100).generate_from_frequencies(plot_data)
# you can save a wordcloud in a file instead of using mathplotlib to show it
#wc.to_file("wordcloud.png")

# configure mathplotlib to show the final picture
plt.figure(figsize=(15, 15))
plt.imshow(wc, interpolation='bilinear')  # interpolation='bilinear' makes sharper lines on a picture
plt.axis('off')
plt.show()


# It is natural to assume that different presidents differ in their word usage. Wordclouds may be used to demonstrate this.

# **Your turn**
# 
# 1. Select any two presidents from the dataset. Build a frequency list and a wordcloud for each of them. Use the list of stopwords from the NLTK package.
#     
# 2. The same as (1), but use the most frequent words from our dataset as a list of stopwords (experiment with different number of stopwords).
# 
# 3. (*) Make two Zipf-plots for speeches before and after 1917. Hint: there is an example in the [Tidytext book](https://www.tidytextmining.com/tfidf.html#zipfs-law).
# 

# # Normalized frequency
# 
# Now that we have started to compare frequency lists (wordclouds), it is useful to represent counts on a normalized scale (presidents vary in eloquence and verbosity!). A conventional unit for word frequencies in corpus linguistics is IPM (Instances Per Million).

# In[401]:


sou_freg = (sou_long
            .assign(totalwords = lambda x: x.groupby(['president']).transform('count')['txt_tokens'])
            .assign(n_words = lambda x: x.groupby(['president', 'words']).transform('count')['txt_tokens'])
            .assign(freq = lambda x: x.n_words / x.totalwords * 1e+6 ) )

sou_freg.head()


# # Wide format
# 
# Long format is handy for frequency counting and requires less resources from a computer to produce calculations. Yet for most statistical modeling and machine learning applications we need a list of features for each text, in columns.
# 
# This is where wide format for text representation is needed.
# 
# For our first experiment with stopwords, we will leave stopwords ONLY.

# In[402]:


sou_stop = sou_freg[sou_freg['words'].isin(stopwords.words('english'))]


# In[403]:


stopwords_dtm = (sou_stop[['president', 'words', 'freq']]
                 .pivot_table(index='president', columns='words', values='freq') )


# In[404]:


stopwords_dtm.head()


# # Stylometry
# 
# Is it true that stopwords should always be removed?
# 
# Stylometry is a collection of methods to automatically measure and detect personal style. Stopwords proved to be a very valuable source for this task.
# 
# Let's compare the distribution of stopwords in the speeches by different presidents.
# 
# To reduce the dimensionality of data, we will use PCA (Principal Components Analysis). [An interactive visualisation that helps understand PCA](http://setosa.io/ev/principal-component-analysis/)

# However, before we proceed with PCA, lets examine out DTM:

# In[405]:


# which columns contain missing values?
stopwords_dtm.isna().any()


# PCA cannot work with missing values, we must exclude them from our further analysis. Can you spot the reason why they got introduced in our dataset?
# 
# Words with missing values:

# In[406]:


missings = (stopwords_dtm
            .isna()
            .any()[stopwords_dtm.isna().any() is True]
            .reset_index()['words'].values )
missings


# Now, before running PCA, we exclude missings.

# In[407]:


stopwords_dtm = stopwords_dtm.drop(missings, axis=1)


# In[408]:


stopwords_dtm.shape


# Finally, we can run PCA.

# In[409]:


from sklearn.decomposition import PCA  # Use 'conda install scikit-learn' if you do not have the package

pca = PCA(n_components=2)  # configure PCA to reduce our data to 2 dimensions

principalComponents = pca.fit_transform(stopwords_dtm)  # Compute PCA


# In[410]:


# extract computed components and combine with our meta-data
principalDf = pd.DataFrame(data = principalComponents,
                           columns = ['principal component 1', 'principal component 2'])

principalDf = pd.concat([pd.Series(stopwords_dtm.index), principalDf], axis = 1)
principalDf.head()


# Biplot graph is a nice visualization for PCA. We can use `mathplotlib` to make a simple variation.

# In[411]:


fig = plt.figure(figsize = (8,8))
ax = fig.add_subplot(1,1,1) 
ax.set_xlabel('Principal Component 1', fontsize = 15)
ax.set_ylabel('Principal Component 2', fontsize = 15)
ax.set_title('2 component PCA', fontsize = 20)

# we will plot president by president
targets = list(principalDf.president.values)
for target in targets:
    indicesToKeep = principalDf['president'] == target
    ax.scatter(principalDf.loc[indicesToKeep, 'principal component 1'],  # add a point on the plot
               principalDf.loc[indicesToKeep, 'principal component 2'], 
               s = 50)
    plt.text(principalDf.loc[indicesToKeep, 'principal component 1'],    # label the added point 
             principalDf.loc[indicesToKeep, 'principal component 2'], s=target)

ax.grid()


# The plot shows all US presidents positioned in a “stopword distribution space”.

# **Your turn:**
# 
# * Repeat PCA and plot a biplot, leaving only personal pronouns instead of all stopwords. Hint: An easy way to obtain a list of personal pronouns — just take first 29 words of the standard stoplist:

# In[412]:


stopwords.words('english')[0:28]

