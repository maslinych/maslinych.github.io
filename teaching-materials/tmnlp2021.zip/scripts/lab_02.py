#!/usr/bin/env python
# coding: utf-8

# # Comparing word usage in contrasting corpora
# 
# Author: Kirill Maslinsky
# 
# Python translation: Sergei Pashakhin
# 
# For social and political science, texts usually serve as proxy to
# some social phenomenon, sentiment, idea, or discourse. In a common
# research design, texts from several institutions, groups or actors
# are collected. These make two (or more) *contrasting corpora*.
# Differences in word usage in these corpora are used to infer
# something about the underlying social/political features of the
# entities these corpora represent.
# 
# During previous class, we reduced the style of different authors to
# a distribution of a few specific words (stopwords, personal
# pronouns, etc.) This allowed us to position all authors in the same
# multidimensional “stylistic space”, and to measure, who's closer to
# whom and on what lexical grounds. A powerful technique.
# 
# The major downside was that we had to select words to use as a base
# for comparison *ourselves*. This was easy with closed-class function
# words. But what if we are interested in comparing *content* of the
# speech? How to select words that are interesting? How to avoid
# arbitrary choice? To accomplish this, we need some statistical tests
# that could show which words are significantly over- or underused in
# one corpus **in contrast** to another.

# # Prepare data
# 
# Load State of the Union data:

# In[1]:


import pandas as pd
import numpy as np
import string
import re


# In[2]:


sou = pd.read_csv("https://github.com/BrianWeinstein/state-of-the-union/blob/master/transcripts.csv?raw=true")


# In[3]:


sou.head()


# In[4]:


sou.info()


# We will now create two corpora for contrasting: speeches by Democratic and Republican presidents since 1917.

# In[5]:


democrats = ["Woodrow Wilson", "Franklin D. Roosevelt", 
             "Harry S. Truman", "John F. Kennedy", "Lyndon B. Johnson", "Jimmy Carter",
             "William J. Clinton", "Barack Obama"]

sou_democrats = sou[sou.president.isin(democrats)]
sou_republicans = sou[(-sou.president.isin(democrats)) & (sou["date"] > "1917-10-25")]


# # More preprocessing. Stemming and lemmatization
# 
# Before we move on to measuring the prevalence of content words, it
# is beneficial to make our text data less noisy. In natural language
# the same word may take various surface forms: plurals, past tense
# etc. This may be of less concern for English, but more so for more
# inflected languages. When we are interested in content, it is better
# to treat all these *wordforms* as the same word.
# 
# There are two common approaches.
# 
# 1. **Stemming**. Simply remove word endings that contain inflection,
# leaving a *stem*. The approach is simple and fast.
# 
# 2. **Lemmatization**. Reduce a word to its dictionary form — a
# *lemma*. This requires more linguistic data (dictionary etc.), but
# gives more precise results. We will stick to this method.
# 
# To perform lemmatization for English, we will continue to rely on `NLTK`.

# This is the preprocessing pipeline from our last lab.
# 
# So far, it can only clean our data from punctiation and digits,
# empty strings and spaces, and tokenize it. Today, we will learn how
# to refine our data by extending our preprocessing pipeline with
# lemmatization. But first, let's do it step by step.
# 
# **Step 1**: clean and tokenize

# In[6]:


from nltk import word_tokenize

punctuation = list(string.punctuation + string.digits + ' ')  # combine all digits and punctuation characters
punctuation = set(punctuation)  # Remember: set() is faster than list() ! 


def preprocess(txt, stopwords):
    clean = []  # a container for the cleaned data
    txt_token = word_tokenize(txt)  # tokenize text
    for token in txt_token:  # iterate over tokenized text
        if token.lower() not in stopwords:  # excludes tokens that are in our stopword-set
            token = re.sub(r'[^a-zA-Z]', "", token.lower())  # exclude punctuation and digits from tokens
            if len(token) > 1:  # exclude empty tokens without information--byproduct of cleaning
                clean.append(token)
    return clean


# In[7]:


annot_dem = (sou_democrats['transcript']
             .apply(preprocess, stopwords=punctuation)  # clean and tokenize
             .to_frame(name='tokens')
             .assign(party="democrat")
             .explode("tokens"))

annot_rep = (sou_republicans['transcript']
             .apply(preprocess, stopwords=punctuation)
             .to_frame(name='tokens')
             .assign(party="republican")
             .explode("tokens"))


# ## Lemmatization with NLTK
# 
# `NLTK` uses [WordNet](https://en.wikipedia.org/wiki/WordNet)
# database for lemmatization. This is an additional resource
# that--when first invoked--`NLTK` will ask you to download. The
# procedure involves matching a token with the database and returning
# the original form of a word. However, sometimes `NLTK` will fail to
# match a word with its' original form as it does not know what part
# of speech (POS) it is. To improve this matching procedure, we have
# to supply our lemmatizing procedure with both token and information
# about POS.
# 
# `NLTK` can classify a word as a POS and return it as a special
# tag. You can read about it
# [here](https://www.nltk.org/book/ch05.html#part_of_speech_tagging_index_term).
# For now, it is not very important to understand these tags, but
# later, you will need them. What is important right now is that
# `WordNet` uses a different tag system! So, we have to do another
# matching procedure before lemmatization: we have to match `NLTK`
# tags with `WordNet` tags.

# In[10]:


from nltk.stem import WordNetLemmatizer  # the WordNet lemmatizer
from nltk.corpus import wordnet  # the WordNet database
from nltk.tag import pos_tag  # NLTK's build-in tags for POS

wnl = WordNetLemmatizer()  # initialize the lemmatizer and shorten the name


def get_wordnet_pos(treebank_tag):
    """the function matches NLTK tag to WordNet tag"""
    if treebank_tag.startswith('J'):
        return wordnet.ADJ
    elif treebank_tag.startswith('V'):
        return wordnet.VERB
    elif treebank_tag.startswith('N'):
        return wordnet.NOUN
    elif treebank_tag.startswith('R'):
        return wordnet.ADV
    else:
        return None


def lemmatize(token):
    """the function takes a token and lemmatizes it"""
    tagged = pos_tag([token])  # Important: pos_tag works only with lists!
                                    # this will increase the time the preprocessing pipeline will take
    for word, tag in tagged:
        wntag = get_wordnet_pos(tag)
        if wntag is None:  # not supply tag in case of None
            lemma = wnl.lemmatize(word) 
        else:
            lemma = wnl.lemmatize(word, pos=wntag)
    return lemma


# Now we can lemmatize our tokens. This will take some noticeable time
# to complete, be patient. To speed up your work, it is always a good
# practice to write your preprocessed data in files and to skip all
# preprocessing computations later on.

# In[11]:


annot_dem['lemma'] = annot_dem['tokens'].apply(lemmatize)
annot_rep['lemma'] = annot_rep['tokens'].apply(lemmatize)


# Now, we will write our preprocessed data and load in back.

# In[12]:


annot_dem.to_csv('./data/annot_dem.csv', index_label=False)
annot_rep.to_csv('./data/annot_rep.csv', index_label=False)


# In[13]:


annot_dem = pd.read_csv('./data/annot_dem.csv')
annot_rep = pd.read_csv('./data/annot_rep.csv')


# In[14]:


annot_dem.head()


# In[15]:


annot_rep.info()


# To make data for comparisons, we now create lemma frequency lists for both corpora and join them in a single table. Filter out rare words (n<10 for both parties).

# In[16]:


party_lemmas = pd.concat([annot_dem, annot_rep], ignore_index=True)


# In[17]:


byparty_df = (party_lemmas
              .groupby(['lemma', 'party'])
              ['lemma'].count()
              .to_frame(name="count")
              .reset_index()
              .pivot(index='lemma', columns="party", values="count")
              .reset_index()
              .fillna(0)
              .query("democrat > 10 | republican > 10") )


# In[20]:


party_lemmas


# # Significance. Dunning log-likelihood (G^2)
# 
# The most commonly used statistical measure to evaluate the
# significance of the difference of a word's frequency in two corpora
# is called log-likelihood (G-squared).
# 
# We start with defining a function that will calculate a list of G2
# values given two columns of frequencies (in corpora A and B).

# In[22]:


def g2(a, b):
    """calculate log likelihood for two columns of frequencies"""
    c = a.sum()
    d = b.sum()
    
    E1 = c * ((a + b) / (c + d))
    E2 = d * ((a + b) / (c + d))
    
    return 2*((a*np.log(a/E1+1e-7)) + (b*np.log(b/E2+1e-7)))


# Now we can calculate log-likelihood for lemma frequency differences for each party:

# In[23]:


party_g2 = (byparty_df
            .assign(g2 = lambda x: g2(x.democrat, x.republican))
            .sort_values('g2', ascending=False)
            .assign(g2 = lambda x: round(x.g2, 2)) )


# In[24]:


party_g2.head()


# Note that the many of the most frequent words turned out to also be
# the most significantly disproportional. This should rise suspicions.

# **Your turn**:
# 
# 1. `g2` difference shows a lot of stopwords in the list. You can
# filter them out to see a cleaner result using the code from our
# previous lab or your refined `preprocess()` function.
# 
# 2. There is another way to solve the same task using only
# part-of-speech tags and no pre-defined stopword list. Hint: what
# part of speech tags closed-class function words will have?

# # Effect size. Log Ratio
# 
# [Friends don't let friends calculate p-values (without understanding
# them).](http://www.scottbot.net/HIAL/?p=24697)
# 
# So we are going to supplement our log-likelihood tests with an
# effect size measure that allow to quantify, how large exactly is the
# difference of frequencies.
# 
# We will use the most conceptually simple effect size measure: Log
# odds ratio (See more details and examples in [Text mining with R
# book](https://www.tidytextmining.com/twitter.html#comparing-word-usage).
# 
# Here we define a function similar to `g2`, and apply it to our data. 

# In[25]:


def logratio(a, b):
    ratio = (a +1) /(a.sum() + 1) / ((b + 1)/(b.sum()+1))
    return np.log(ratio)  # https://numpy.org/doc/stable/reference/generated/numpy.log.html


# In[26]:


party_lr = (party_g2
 .sort_values('g2', ascending=False)
 .assign(g2 = lambda x: round(x.g2, 2))
 .assign(logratio = lambda x: logratio(x.democrat, x.republican)) )


# In[27]:


(party_lr
 .sort_values("logratio", key= lambda x: x.abs(), ascending=False)
 .head(15) )


# Words most acutely overused by one or the other party:

# In[28]:


(party_lr
 .query('democrat > 0 & republican > 0')
 .sort_values('logratio', key= lambda x: x.abs(), ascending=False)
 .head(15))


# The same result in a nice looking plot.

# In[29]:


from plotnine import *


# In[32]:


# 1. prepare data for the plot

dem_rep_word_usage = (party_lr
 .query('democrat > 0 & republican > 0')
 .sort_values('logratio', key= lambda x: x.abs(), ascending=False)
 .assign(side = lambda x: x.logratio > 0)
 .groupby('side', sort=True)
 .head(16) )  # take top 16 lemmas for each party

# 2. get the order of lemmas to arrange plot by values instead of
# alphabetically
order = (dem_rep_word_usage[['lemma', 'logratio']]
         .sort_values('logratio')['lemma']
         .to_list() )

# 3. change the ored of the lemma variable with the new one
dem_rep_word_usage = (dem_rep_word_usage
                      .assign(lemma = lambda x: pd.Categorical(x.lemma, order)) )


# In[33]:


# plot

(ggplot(dem_rep_word_usage, aes(x='lemma', y='logratio', fill='side'))
 +geom_col(show_legend=False)
 +coord_flip()
 +ylab("log odds ratio (Democrats/Republicans)") )


# For which of these highly disproportional words we also have enough
# evidence to claim statistical significance of the difference?

# # From words to Named Entities
# 
# A named entity is a textual reference to some real-world entity
# (persons, locations, organizations, etc.). Named entity recognition is a standard NLP task. 
# 
# **Your turn**:
# 
# 1. Compare the relative frequency of use of LOCATION entities in the
# corpora of speeches of Republican/Democratic presidents that we have
# created. Are there any significant differences? Use log-likelihood
# score and log-odds ratio to decide.
# 
# **Hint**: To obtain annotated named entities you can use
# **`nltk.ne_chunk()` (see example
# **[here](https://towardsdatascience.com/named-entity-recognition-with-nltk-and-spacy-8c4a7d88e7da)). You
# **can also look into `spaCy` package as an alternative to `NLTK` for
# **tokenization, lemmatization and named-entity detection (learn more
# **[here](https://spacy.io/usage/linguistic-features#named-entities)).
