#!/usr/bin/env python
# coding: utf-8

# In[3]:


import pandas as pd
import numpy as np
import string
import re
from nltk import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer  # the WordNet lemmatizer
from nltk.corpus import wordnet  # the WordNet database
from nltk.tag import pos_tag  # NLTK's build-in tags for POS
from sklearn.metrics.pairwise import cosine_similarity  # computes pairwise cosine on a df
from plotnine import ggplot, aes, geom_tile, scale_fill_gradient2, scale_x_discrete, scale_y_discrete, element_text, theme

trash = stopwords.words('english')
trash = set(trash + list(string.punctuation + string.digits + ' '))
#trash = set(list(string.punctuation + string.digits + ' '))
wnl = WordNetLemmatizer()


# In[4]:


sou = pd.read_csv("https://github.com/BrianWeinstein/state-of-the-union/blob/master/transcripts.csv?raw=true")


# # Vector space model of text
# 
# Actually, we have already seen it without naming it. When text is
# represented in wide format (a row for a document, a column for a
# word), each document is reduced to a series of numbers — a
# vector. Since all the documents in a table share the same columns,
# they are effectively put in the same vector space. This mean that
# mathematical notions of distance and angle now may be applied to
# compare documents.
# 
# Vectors for documents having many words in common and in similar
# proportions will be close in the space. Vectors for documents,
# sharing many common words, but maybe with varying proportions will
# have a small angle between them.
# 
# To evaluate documents' similarity in content it is more useful to
# inspect angles (cosine of the angle, to be more exact).

# ### A note on Python code
# 
# As it was mentioned before, Python has may options for NLP tasks. It
# is possible to implement most of them with `NLTK`. However, the more
# data and advanced computation you have at hands, the less convinient
# `NLTK` becomes. For the sake of studying we will proceed with
# `NLTK`, and at the bottom of the notebook you will find an appendix
# with faster and more convinient options.

# In[5]:

# our preprocessing pipeline involving lemmatization and cleaning from stopwords and trash characters
def get_wordnet_pos(treebank_tag):
    """match NLTK tag to WordNet tag"""
    if treebank_tag.startswith('J'):
        return wordnet.ADJ
    elif treebank_tag.startswith('V'):
        return wordnet.VERB
    elif treebank_tag.startswith('N'):
        return wordnet.NOUN
    elif treebank_tag.startswith('R'):
        return wordnet.ADV
    else:
        return None


def lemmatize(txt):
    """lemmatize a text"""
    lemmas = []
    txt_tokens = word_tokenize(txt)
    tagged = pos_tag(txt_tokens)
    for word, tag in tagged:
        wntag = get_wordnet_pos(tag)
        if wntag is None:  
            lemmas.append(wnl.lemmatize(word)) 
        else:
            lemmas.append(wnl.lemmatize(word, pos=wntag))
    
    return lemmas


def preprocess(txt, stopwords):
    """lemmatize and clean text from stopwords"""
    clean = []  
    txt_token = lemmatize(txt)  
    for token in txt_token:  
        if token.lower() not in stopwords:  # excludes tokens that are in our stopword-set
            token = re.sub(r'[^a-zA-Z]', "", token.lower())  # exclude punctiation and digits from tokens
            if len(token) > 1:  # exclude empty tokens without information--byproduct of cleaning
                clean.append(token)
    return clean


# In[6]:


usthem_dtm = (sou
              .head(25)
              [['president', 'transcript']]
              .assign(word=lambda x: x.transcript.apply(preprocess, stopwords=trash))
              [['president', 'word']]
              .explode('word')
              .query("word in ['might', 'must', 'may']")  # 'might' instead of 'can' (a stopword) 
              .assign(count=lambda x: x.groupby(['president', 'word'])['word']
                      .transform('count'))
              .pivot_table(index='president', columns='word', values='count')
              .fillna(0))
usthem_dtm


# This form of presentation of text is so widely used that it has its
# own name — *document-term matrix*.
# 
# Below is the matrix of cosine distances between these
# vectors. Values closer to 1 mean more similar documents.

# In[7]:


pd.DataFrame(cosine_similarity(usthem_dtm),
             columns=usthem_dtm.T.columns,
             index=usthem_dtm.T.columns)


# # Weighted frequency. TF-IDF
# 
# Not all words are equally useful to compare documents'
# content. Those words encountered once (hapax legomena) are of no use
# for comparison. Words found in every document also doesn't help to
# distinguish text content. The most useful ones are in the middle. To
# give them more weight in computing docuemnt similarity, TF-IDF was
52# introduced.
# 
# TF-IDF stands for (term frequency — inverse document
# frequency). Here we will use `sklearn` to compute TF-IDF.

# In[120]:

# sample 5 random speeches and tokenize
sou5 = (sou.sample(5)
        [['date', 'transcript']]
        .assign(word=lambda x: x.transcript.apply(preprocess, stopwords=trash))
        [['date', 'word']]
        .explode('word'))

# transform into a sparse document-term-matrix
sparseint = pd.SparseDtype(int, fill_value=0)
sparsefloat = pd.SparseDtype(float, fill_value=0)

sou5_dtm = (sou5
            .assign(count=lambda x: x.groupby(['date', 'word'])['word']
                    .transform('count')
                    .astype(sparseint))
            .pivot_table(index='date', columns='word', values='count',
                         fill_value=0))

# compute values for TF-IDF formula and bind a column with TF-IDF values
sou5_tfidf = (sou5
              .assign(tf=lambda x: x.groupby(['date', 'word'])['word']
                      .transform('count'))
              .assign(df=lambda x: x.groupby(['word'])['date']
                      .transform('nunique'))
              .assign(tfidf=lambda x: x.tf*np.log(x.date.nunique()/x.df)))

# join everything together
sou_long = (sou
            [['date', 'transcript']]
            .assign(word=lambda x: x.transcript.apply(preprocess, stopwords=trash))
            [['date', 'word']]
            .explode('word'))

sou_tfidf = (sou_long
             .assign(tf=lambda x: x.groupby(['date', 'word'])['word']
                     .transform('count'))
             .assign(df=lambda x: x.groupby(['word'])['date']
                     .transform('nunique'))
             .assign(tfidf=lambda x: x.tf*np.log(x.date.nunique()/x.df)))

# # Measuring inter-document similarity
# 
# Now we are ready to measure the similarity of speeches based on
# TF-IDF scores. We omit words that have 0 TF-IDF, and those that are
# encountered less than 10 times in the corpus.

# In[592]:


# this is supposed to filter rare words and construct a dtm
sou_dtm = (sou_tfidf
           .query('tf > 25 & tfidf > 0')
           .astype({'tfidf': sparsefloat})
           .pivot_table(index='date', columns='word', values='tfidf',
                        fill_value=0))



# In[593]:


# compute cosine similiarity on a dtm seems to work well, but I
# suspect TF-IDF values to mess things up for the resulting plot
cos = pd.DataFrame(cosine_similarity(sou_dtm),
                   columns=sou_dtm.T.columns,
                   index=sou_dtm.T.columns)


# And finally plot speech similarity graph (as in the paper by [Rule
# et al.](http://www.pnas.org/content/112/35/10837)).

# In[594]:


# preparing data for the plot
# I tested this pipeline and it represents the data as in the original R script
cos_plot = (cos
            .melt(ignore_index=False)
            [['date', 'value']]
            .rename(columns={'date': 'date_y'})
            .reset_index()
            .assign(date=lambda x: pd.Categorical(x.date.str.slice(0, 4)))
            .assign(date_y=lambda x: pd.Categorical(x.date_y
                                                    .str.slice(0, 4),
                                                    pd.Categorical(x.date)
                                                    .categories
                                                    .sort_values(ascending=False))))

keeping = [str(year) for year in range(1790, 2011, 10)]


# In[195]:


# the exact plot as in the original R script
(ggplot(cos_plot, aes(x='date', y='date_y', fill='value'))
 + geom_tile()
 + scale_fill_gradient2(low="lightblue", high="darkblue", midpoint=0.5, mid="steelblue")
 + scale_y_discrete(breaks=keeping)
 + scale_x_discrete(breaks=keeping)
 + theme(axis_text_x=element_text(angle=90)))


# # Appendix
# 
# Below is the better way to reproduce the original R script. One
# better use `sklearn` for DTM-related tasks, and computing TF-IDF

# In[218]:


from sklearn.feature_extraction.text import TfidfVectorizer
vectorizer = TfidfVectorizer(use_idf=True, min_df=10)


# In[219]:


# get the DTM with TF-IDF
X = vectorizer.fit_transform(sou['transcript'])


# In[220]:


# make a pandas df from the sklearn output
sou_tfidf2 = pd.DataFrame(X.todense(), columns=vectorizer.get_feature_names_out())


# In[221]:


# compute cosine similiarity and attach the metadata
cos = pd.DataFrame(cosine_similarity(sou_tfidf2),
                   columns=sou_tfidf2.T.columns,
                   index=sou_tfidf2.T.columns)
cos['date'] = sou['date']


# In[222]:


# prepare data for ggplot
# somehow different from the same pipeline above, but seems to be doing everything right
cos_plot = (cos
            .melt('date')
            [['date', 'value']]
            .assign(date_y=lambda x: x.date)
            .assign(date=lambda x: pd.Categorical(x.date.str.slice(0, 4)))
            .assign(date_y=lambda x: pd.Categorical(x.date_y
                                                    .str.slice(0, 4),
                                                    pd.Categorical(x.date)
                                                    .categories
                                                    .sort_values(ascending=False))))

keeping = [str(year) for year in range(1790, 2011, 10)]


# In[223]:


# the same code for plotting, but the results are wrong
(ggplot(cos_plot, aes(x='date', y='date_y', fill='value'))
 + geom_tile()
 + scale_fill_gradient2(low="lightblue", high="darkblue", midpoint=0.5, mid="steelblue")
 + scale_y_discrete(breaks=keeping)
 + scale_x_discrete(breaks=keeping)
 + theme(axis_text_x=element_text(angle=90)))


# In[ ]:




