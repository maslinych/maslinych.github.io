#!/usr/bin/env python
# coding: utf-8

# # Words as measurements
# 
# Author: Kirill Maslinsky
# 
# Python translation: Sergei Pashakhin
# 
# An easy, accessible, questionable and misleading way to do sentiment
# analysis with R and tidytext package is thoroughly presented in the
# [tidytext
# book](https://www.tidytextmining.com/sentiment.html#the-sentiments-dataset).
# 
# You may try it yourself, yet I would not recommend either to extend
# its use beyond simple exercise, or to regard the results as a base
# for any serious inferences.
# 
# The pedagogical value of this approach to sentiment analysis is that
# it serves as a clear example of the dictionary method in text
# mining. The method boils down to the counting the occurrences of
# words from some closed list (a dictionary) in order to categorize
# the texts where they are found, on some high-level scale.
# 
# 
# **Let's conjure the code together**
# 
# ### Dataset

# In[1]:


import pandas as pd
import numpy as np
from plotnine import *
import string
import re
from nltk import word_tokenize
from nltk.corpus import stopwords

trash = stopwords.words('english')
trash = set(trash + list(string.punctuation + string.digits + ' '))


# In[2]:


# our preprocessing pipeline involving lemmatization and cleaning from stopwords and trash characters
def get_wordnet_pos(treebank_tag):
    """match NLTK tag to WordNet tag"""
    if treebank_tag.startswith('J'):
        return wordnet.ADJ
    elif treebank_tag.startswith('V'):
        return wordnet.VERB
    elif treebank_tag.startswith('N'):
        return wordnet.NOUN
    elif treebank_tag.startswith('R'):
        return wordnet.ADV
    else:
        return None


def preprocess(txt, stopwords):
    """lemmatize and clean text from stopwords"""
    clean = []  
    txt_token = word_tokenize(txt)  
    for token in txt_token:  
        if token.lower() not in stopwords:  # excludes tokens that are in our stopword-set
            token = re.sub(r'[^a-zA-Z]', "", token.lower())  # exclude punctiation and digits from tokens
            if len(token) > 1:  # exclude empty tokens without information--byproduct of cleaning
                clean.append(token)
    return clean


# In[3]:


sou = pd.read_csv("https://github.com/BrianWeinstein/state-of-the-union/blob/master/transcripts.csv?raw=true")


# In[4]:


sou.head()


# In[5]:


democrats = ["Woodrow Wilson", "Franklin D. Roosevelt", 
             "Harry S. Truman", "John F. Kennedy", "Lyndon B. Johnson", "Jimmy Carter",
             "William J. Clinton", "Barack Obama"]


# In[6]:


sou_party = (sou
             .query('date > "1917-10-25"')
             .assign(party = lambda x: np.where(x['president'].isin(democrats) == True, "democrat", "republican" )))


# ### Sentiment Dictionary
# 
# English:
# * `AFINN`: [link](https://www2.imm.dtu.dk/pubdb/pubs/6010-full.html) -- file 'AFINN-111.txt'
# * `BING`: [link](https://www.cs.uic.edu/~liub/FBS/sentiment-analysis.html) -- two files for positive and negative words.
# * `NRC`: [link](https://saifmohammad.com/WebPages/lexicons.html) -- file 'NRC-Emotion-Intensity-Lexicon-v1.txt'
# 
# Russian:
# * `PolSentiLex`: [link](https://github.com/hse-scila/PolSentiLex) -- file 'PolSentiLex-raw.csv' (for social media text on social and political issues)
# * `RuSentiLex`: [link](https://www.labinform.ru/pub/rusentilex/index.htm) -- [file](https://www.labinform.ru/pub/rusentilex/rusentilex_2017.txt) 'rusentilex_2017.txt' (general purpose)
# * `EthnoHate`: Detecting hate speech directed towards ethnic groups
#     * https://scila.hse.ru/ethnohate (in Russian, see papers) -- annotated corpora are availiable there.
# 

# In[7]:


affin = pd.read_table('./data/AFINN/AFINN-111.txt', sep='\t', header=None)
affin.columns = ['word', 'score']
affin.head()


# In[8]:


nrc = pd.read_table('./data/NRC-Emotion-Intensity-Lexicon-v1/NRC-Emotion-Intensity-Lexicon-v1.txt', sep='\t')
nrc.head()


# Apply it:

# In[9]:

(sou_party[['party', 'transcript']]
            .assign(word=lambda x: x.transcript.apply(preprocess, stopwords=trash))
            [['party', 'word']]
            .explode('word')
            .assign(n=lambda x: x.groupby(['party', 'word'])['word'].transform('count'))
 )


sou_sent = (sou_party[['party', 'transcript']]
            .assign(word=lambda x: x.transcript.apply(preprocess, stopwords=trash))
            [['party', 'word']]
            .explode('word')
            .assign(n=lambda x: x.groupby(['party', 'word'])['word'].transform('count'))
            .pivot_table(values='n', columns='party', index='word', fill_value=0)
            .reset_index())
sou_sent.head()


## 1. Which party affiliation makes for more positive/negative speeches? (on average)

## 2. Who's the most angry presindent?

angry_words = nrc.query('emotion=="anger"') 

anger_sent = (sou_party[['president', 'transcript']]
              .assign(word=lambda x: x.transcript.apply(preprocess, stopwords=trash))
              [['president', 'word']]
              .explode('word')
              .assign(n=lambda x: x.groupby(['president', 'word'])['word'].transform('count'))
              .reset_index()
              .merge(angry_words, on="word")
              .groupby(['president'])
              .sum()
)
              
# # Dictionary approach: problems and a solution
# 
# Two problems of dictionaries:
# 
# * Arbitrary selection of words (and, hence, possible critique that a
# * dictionary may be subjective and prone to systematic omissions).
# * Domain dependence.
# 
# An approach to alleviate those problems — Dictionary induction.
# 
# An outline of the method:
# 
# 1. Obtain a collection of texts from the relevant domain.

# 2. Find a signal that is external to the texts and correlated to the
# quantity that you are going to measure. This may be some metadata
# (number of stars in a review), or a list of seed words provided by experts.

# 3. Use some statistical method to find words that are associated
# with the external signal in the collection. These words make up the
# induced dictionary.

# 4. Use the dictionary obtained in (3) to measure the quantity of
# interest in other texts from the same domain.
# 
# ## An example problem
# 
# 
# 
# 1. Our familiar contrasting collection — speeches by Democratic and
# Republican presidents since 1917.
# 
# 2. External signal: metadata — a president's party affiliation.
# 
# 3. Statistical method: find words highly associated with one or the
# other party subcorpus using PMI statistic (Pointwise Mutual
# Information). We will only include words from a sentiment lexicon
# into consideration.
# 
# 4. Use the induced democratic/republican induced vocabulary to
# measure the “affiliation of sentiment on some other texts”.
# 
# ## A solution


# ### Pointwise mutual information
# 
# ``pmi(x, y) = log( P(x, y) / P(x)P(y) )``

# In[10]:


def pmi(a, b):
    """Compute pmi of two vectors"""
    sum_a = a.sum()
    sum_b = b.sum()
    p_xy = a/sum_a
    p_x = (a + b) / (sum_a + sum_b)
    p_y = sum_a / (sum_a + sum_b)
    return (np.log((p_xy) / ((p_x * p_y))))  # (p_xy + 1)? to get rid of 0s?


# Now build two columns with PMI counts for both parties.

# In[11]:


sou_pmi = (sou_sent
           .assign(pmi_dem=lambda x: pmi(x.democrat+1, x.republican+1))
           .assign(pmi_rep=lambda x: pmi(x.republican+1, x.democrat+1)))

sou_pmi.head()


# Now let's inspect the dictionary.

# ### Use for measurement

# In[12]:


sou_pre1917 = (sou.query('date < "1917-10-25"')
               .assign(word = lambda x: x.transcript.apply(preprocess, stopwords=trash))
               .explode('word')
               .merge(sou_pmi, how='inner')
               .groupby(['president'], as_index=False).agg({'pmi_dem': 'sum', 'pmi_rep': 'sum'})
               .assign(color = lambda x: x.pmi_dem - x.pmi_rep))


# In[13]:


sou_pre1917


# Plot it:

# In[29]:


# Putting a lot of text can make your plot unreadable
# plotnine can use adjustText package for matplotlib to arrange text lables
# you have to install it either from conda or pip:
# conda -c forge install adjustText
# (you may need to restart jupyter kernel to make adjust_text work)
# https://adjusttext.readthedocs.io/en/latest/
# geom_text(adjust_text={ params })
# i.e.
#
#adjust_text_dict = {'expand_points': (2, 2)}
#
# But first, let's plot a sample of our data to make sure it works as we planned:
(ggplot(sou_pmi.query('democrat > 10 & republican >10').sample(30), aes(x='pmi_dem', y='pmi_rep', color='color', label='word'))
 +scale_color_gradient(low="red", high="blue")
 +geom_text()
# +geom_text(adjust_text=adjust_text_dict)
)


# In[ ]:




