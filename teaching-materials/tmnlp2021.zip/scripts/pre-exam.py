import pandas as pd

d = pd.read_csv("./data/Womens Clothing E-Commerce Reviews.csv")
d.info()

## Pre-exam review

# 1. Tokenize review texts. Build a word frequency list. Compare the
#    top-100 most frequent words with the standard list of stopwords for
#    English from the nltk package. Do you think any of the words in the
#    top-100 list should be considered stopwords for this dataset?
#    Adjust stopwords list, taking into account both top-100 and
#    standard stopwords.


# 2. Normalize data (remove punctuation, numbers, stopwords). Consider
#    two corpus parts for comparison: those recommended by customers
#    (Recommended IND==1) and those not recommended (0). Compute
#    normalized word frequencies (IPM) for all the words in both parts
#    of the corpus. Select top-15 most characteristic words for both
#    parts using Kilgariff's simple maths approach. 
   
# 3. Filter out words not present in either part of the corpus
#    (freq==0), and compute both log-likelihood (G^2) and logratio
#    values. Select top-15 most characteristic words for both parts
#    of the corpus using a combination of these metrics: choose only
#    those words with high logratio that also has high log-likelihood
#    level (>15). How does the resulting list differ from the list
#    obtained by “simple maths”? 

# 4. Select those products (identified by 'Clothing ID') that have at
#    least five reviews. Build a document-term matrix using text of all
#    reviews for each product as document and TF-IDF as values (instead
#    of raw frequencies). Compute cosine similarity for every pair of
#    documents in the document-term matrix, save results in a data
#    frame. Do products of the same class (see 'Class Name') have more
#    similar document vectors? [Hint: compare average in-class cosine
#    similarity to average similarity of random sample of product
#    vectors.]
   
# 5. Select highest rated (Rating==5) and lowest rated (Rating<3)
#    reviews. Use PMI to induce a dictionary of words most closely
#    associated with high/low review rating. Is it appropriate to use
#    the resulting wordlists to automatically score the sentiment of the
#    reviews of the similar products? Test the scoring on the
#    medium-rated reviews (Rating=3). Select top-10 medium-rated reviews
#    with the highest and lowest score. Do they actually differ in
#    sentiment? 

