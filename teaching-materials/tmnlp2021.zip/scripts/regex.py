#!/usr/bin/env python
# coding: utf-8

import os
import re
import sys


def read_txt(filename):
    with open(filename, 'r') as f:
        try:
            lines = f.readlines()
        except(UnicodeDecodeError):
            print("Unicode decode error:", filename)
            return []
    return lines

def read_data(datadir):
    files = os.listdir(datadir)
    plays = []
    for f in files:
        plays.append(read_txt(os.path.join(datadir, f)))
    return plays


def remove_characters(line):
    return re.sub("^([A-Z]+\\b ?)+", '', line)

cleanplays = []
for play in plays:
    cleanlines = []
    for line in play:
        cleanlines.append(remove_characters(line))
    cleanplays.append(cleanlines)

